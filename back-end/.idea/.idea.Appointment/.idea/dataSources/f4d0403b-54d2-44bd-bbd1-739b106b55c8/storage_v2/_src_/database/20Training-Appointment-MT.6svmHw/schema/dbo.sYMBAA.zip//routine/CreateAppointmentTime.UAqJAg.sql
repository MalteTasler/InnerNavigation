CREATE PROCEDURE  [dbo].[CreateAppointmentTime]
    @BoardId int,
    @WeekDay int,
    @StartTime datetimeoffset,
    @EndTime datetimeoffset

AS
begin
    Insert into AppointmentTime
    ([BoardId],
     [WeekDay],
     [StartTime],
     [EndTime])

    values(		@BoardId,
                   @WeekDay,
                   @StartTime,
                   @EndTime)

end
go

