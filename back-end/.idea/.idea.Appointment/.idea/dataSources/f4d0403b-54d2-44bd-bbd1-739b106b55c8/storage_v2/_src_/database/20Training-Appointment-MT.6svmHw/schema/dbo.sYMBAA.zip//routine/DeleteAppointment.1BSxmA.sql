CREATE PROCEDURE [dbo].[DeleteAppointment]
@userId int,
	@Id int

AS
begin
	
	UPDATE Appointment 
	SET [DeleteTime] = getdate()
	WHERE 
	Id = @Id
	UPDATE Appointment
	SET [DeleteUserId] = @userId
	WHERE
	Id = @Id
				
end
go

