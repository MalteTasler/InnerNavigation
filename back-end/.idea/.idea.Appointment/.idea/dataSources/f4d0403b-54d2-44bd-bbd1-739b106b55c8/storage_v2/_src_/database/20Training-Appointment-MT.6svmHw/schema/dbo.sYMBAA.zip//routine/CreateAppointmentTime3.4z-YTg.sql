CREATE PROCEDURE  [dbo].[CreateAppointmentTime3]
	@BoardId int =1,
	@WeekDay int = 3,
	@StartTime datetimeoffset = '2020-12-20 20:30:00 +01:00',
	@EndTime datetimeoffset = '2020-12-20 20:57:00 +01:00'

AS
begin
	declare @dbId int
	DECLARE @selectId int
	declare @startId int
	declare @endId int
	declare @isSameId int
	declare @canBeDeletedId int
	declare @onlyStartTimeIsBigger int
	declare @onlyEndTimeIsSmaller int
	declare @sameWeekId int
	declare @sameBoardId int
	set @isSameId = (select Id from AppointmentTime where (WeekDay = @WeekDay) AND (BoardId = @BoardId) AND (StartTime = @StartTime) AND (EndTime = @EndTime))
	set @dbId = (select Id from AppointmentTime where (WeekDay = @WeekDay) AND (BoardId = @BoardId) AND (StartTime <= @StartTime) AND (EndTime >= @EndTime))
	set @startId = (select Id from AppointmentTime where (WeekDay = @WeekDay) AND (BoardId = @BoardId) AND (StartTime <= @StartTime))
	set @canBeDeletedId = (select Id from AppointmentTime	where (WeekDay = @WeekDay) AND (BoardId = @BoardId) AND ((StartTime > @StartTime) AND (EndTime < @EndTime)))
	set @onlyStartTimeIsBigger = (select Id from AppointmentTime	where (WeekDay = @WeekDay) AND (BoardId = @BoardId) AND ((StartTime > @StartTime) AND (EndTime >= @EndTime)) )
	set @onlyEndTimeIsSmaller = (select Id from AppointmentTime	where (WeekDay = @WeekDay) AND (BoardId = @BoardId) AND ((StartTime <= @StartTime) AND (EndTime < @EndTime)))
	set @sameWeekId = (select Id from AppointmentTime where BoardId = @BoardId AND (WeekDay = @WeekDay))
	set @sameBoardId = (select Id from AppointmentTime where BoardId = @BoardId)
														

	set @endId = (select Id from AppointmentTime where (WeekDay = @WeekDay) AND (BoardId = @BoardId) AND (EndTime >= @EndTime))
		
	if(@isSameId is null)
		begin
		if(@dbId is null OR @startId is null OR @endId is null)
			begin
			if(@dbId is null)
				begin
				Insert into AppointmentTime (

							[BoardId],
							[WeekDay],
							[StartTime],
							[EndTime])

				values(		@BoardId,
							@WeekDay,
							@StartTime,
							@EndTime)
				set @selectId = Scope_Identity()
				DELETE FROM AppointmentTime
				WHERE Id = @canBeDeletedId
				END
			
			Update AppointmentTime
			set EndTime = @EndTime
			where Id = @onlyEndTimeIsSmaller
			set @selectId = (select Id from AppointmentTime
			where Id = @onlyEndTimeIsSmaller)
			Update AppointmentTime
			set StartTime = @StartTime
			where Id = @onlyStartTimeIsBigger
			set @selectId = (select Id from AppointmentTime
			where Id = @onlyEndTimeIsSmaller)
			select	Id,
					[BoardId],
					[WeekDay],
					[StartTime],
					[EndTime], 
					CreationTime 
			from AppointmentTime 
			where @selectId = Id 
			end
		
			/*
		if(@startId is null AND @endId is not null)
			begin
			while((select Id from AppointmentTime where (WeekDay = @WeekDay) AND (BoardId = @BoardId) AND (EndTime <= @EndTime)) is not null)
				begin
					UPDATE Appointment 
					SET DELETE_TIME = datetimeoffset
					WHERE EndTime <= @EndTime
				end
			end
		if(@startId is not null And @endId is null)
			begin
			while((select Id from AppointmentTime where (WeekDay = @WeekDay) AND (BoardId = @BoardId) AND (EndTime <= @EndTime)) is not null)
				begin
					UPDATE Appointment 
					SET DELETE_TIME = datetimeoffset
					WHERE EndTime <= @EndTime
				end
			end*/
		end
end
go

