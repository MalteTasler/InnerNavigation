CREATE VIEW [dbo].[viAppointment]
	AS SELECT Appointment.Id, 
	Appointment.BoardId,
	Appointment.Comment,
	Appointment.UserId,
	ChaynsUser.FirstName,
	ChaynsUser.LastName,
	ChaynsUser.PersonId,
	Appointment.Topic,
	Appointment.Type,
	Appointment.WalletGuid,
	Appointment.StartTime,
	Appointment.EndTime,
	Appointment.CreationTime
	FROM Appointment
	INNER JOIN ChaynsUser
	ON Appointment.UserId=ChaynsUser.Id
	WHERE Appointment.DeleteTime IS NULL
go

