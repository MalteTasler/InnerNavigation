CREATE PROCEDURE [dbo].[CreateAppointment]
    @BoardId int,
    @StartTime datetimeoffset,
    @EndTime datetimeoffset,
    @PersonId nvarchar(9),
    @FirstName nvarchar(64),
    @LastName nvarchar(64),
    @Type int,
    @Comment nvarchar(MAX),
    @Topic nvarchar(128),
    @EmailAddress nvarchar(64),
    @PhoneNumber nvarchar(32)

AS
begin
    declare @dbId int
    declare @weekdayname int
    declare @UserId int
    set @weekdayname = DATEPART(WEEKDAY, @StartTime)

    /*if((select Id from AppointmentTime where (WeekDay = @weekdayname)) is null)
        begin*/
            
    
    /* if the User is not already registered in database, create a new user in the database
       After that use that data from the User database*/
            if((select Id from ChaynsUser where (PersonId = @PersonId)) is not null) 
                begin
                set @dbId = (select Id from ChaynsUser where (PersonId = @PersonId));
                end
            else
                begin
                INSERT INTO ChaynsUser
                (PersonId, FirstName, LastName, EmailAddress, PhoneNumber)
                values
                (@PersonId, @FirstName, @LastName, @EmailAddress, @PhoneNumber)
                set @dbId = SCOPE_IDENTITY()
                INSERT INTO Appointment
                (BoardId, UserId, [Type], Topic, Comment, StartTime, EndTime)
                values
                (@BoardId, @dbId, @Type, @Topic, @Comment, @StartTime, @EndTime)
                end
            INSERT INTO Appointment
            (BoardId, UserId, [Type], Topic, Comment, StartTime, EndTime)
            values
            (@BoardId, @dbId, @Type, @Topic, @Comment, @StartTime, @EndTime)

        /*end
    else
        begin
            if((select Id from AppointmentTime where WeekDay = @weekdayname and StartTime >= @StartTime ) is null and
               (select Id from AppointmentTime where WeekDay = @weekdayname and EndTime <= @EndTime) is null)
                begin
                    INSERT INTO ChaynsUser
                    (PersonId, FirstName, LastName, EmailAddress, PhoneNumber)
                    values
                    (@PersonId, @FirstName, @LastName, @EmailAddress, @PhoneNumber)
                    set @dbId = SCOPE_IDENTITY()
                    INSERT INTO Appointment
                    (BoardId, UserId, [Type], Topic, Comment, StartTime, EndTime)
                    values
                    (@BoardId, @dbId, @Type, @Topic, @Comment, @StartTime, @EndTime)
                end
        end*/
end
go

