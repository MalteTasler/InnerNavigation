CREATE PROCEDURE [dbo].[UpdateBoard]
	@Id int,
	@Room nvarchar(64),
	@Comment nvarchar(MAX),
	@allowPhone bit,
	@allowChat bit,
	@allowVideo bit,
	@TimeSlotInterval int
AS
	
	begin
	Update Board
	set [Room] = COALESCE(@Room, [Room]),
	[Comment] = COALESCE(@Comment, [Comment]),
	[AllowPhone] = COALESCE(@allowPhone, [allowPhone]),
	[AllowChat] = COALESCE(@allowChat, [allowChat]),
	[AllowVideo] = COALESCE(@allowVideo, [allowVideo]),
	[TimeSlotInterval] = COALESCE(@TimeSlotInterval, [TimeSlotInterval])
				
			Where Id = @Id
	select	Id,
			[LocationId],
			[SiteId],
			[TappId],
			[Room],
			[Comment],
			[AllowPhone],
			[AllowChat],
			[AllowVideo],
			[TimeSlotInterval]
			CreationTime 
	from Board 
	where @Id = Id
	/*select	Id,
			[BoardId],
			[WeekDay],
			[StartTime],
			[EndTime],
			[CreationTime]
	from AppointmentTime
	where @Id = [BoardId]*/
	end
go

