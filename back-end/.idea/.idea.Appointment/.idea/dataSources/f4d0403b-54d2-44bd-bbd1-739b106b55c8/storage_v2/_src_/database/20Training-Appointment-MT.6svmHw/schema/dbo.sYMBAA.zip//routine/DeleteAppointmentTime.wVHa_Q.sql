CREATE PROCEDURE [dbo].[DeleteAppointmentTime]
	/*@StartTime datetimeoffset,
	@EndTime datetimeoffset*/
AS
begin
	DELETE FROM AppointmentTime
	/*WHERE StartTime = @StartTime AND EndTime = @EndTime*/
end
go

