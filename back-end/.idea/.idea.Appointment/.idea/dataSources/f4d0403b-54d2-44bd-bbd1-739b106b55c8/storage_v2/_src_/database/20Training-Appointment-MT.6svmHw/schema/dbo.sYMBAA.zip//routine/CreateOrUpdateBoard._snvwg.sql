CREATE PROCEDURE[dbo].[CreateOrUpdateBoard]
	@LocationId int,
	@SiteId nvarchar(11),
	@TappId int,
	@Room nvarchar(64),
	@Comment nvarchar(MAX),
	@allowPhone bit,
	@allowChat bit,
	@allowVideo bit,
	@TimeSlotInterval int

AS
begin

		declare @dbId int
		declare @WeekDay int
		declare @StartTime datetimeoffset
		declare @EndTime datetimeoffset
		set @WeekDay = 1
		set @StartTime = '2020-12-20 15:30:00 +01:00'
		set	@EndTime = '2020-12-20 20:30:00 +01:00'
			print 'Creating data.';
			Insert into Board (

						[LocationId],
						[SiteId],
						[TappId],
						[Room],
						[Comment],
						[AllowPhone],
						[AllowChat],
						[AllowVideo],
						[TimeSlotInterval])
			values(		@LocationId,
						@SiteId,
						@TappId,
						@Room,
						@Comment,
						@allowPhone,
						@allowChat,
						@allowVideo,
						@TimeSlotInterval)
						set @dbId = Scope_Identity()
			Insert into AppointmentTime (

						[BoardId],
						[WeekDay],
						[StartTime],
						[EndTime])
			values(		@dbId,
						1,
						null,
						null)
			Insert into AppointmentTime (

						[BoardId],
						[WeekDay],
						[StartTime],
						[EndTime])
			values(		@dbId,
						2,
						'2020-12-20 09:30:00 +01:00',
						'2020-12-20 15:30:00 +01:00')
			/*Insert into AppointmentTime (

						[BoardId],
						[WeekDay],
						[StartTime],
						[EndTime])
			values(		@dbId,
						3,
						9.00,
						17.00)
			Insert into AppointmentTime (

						[BoardId],
						[WeekDay],
						[StartTime],
						[EndTime])
			values(		@dbId,
						4,
						9.00,
						17.00)
			Insert into AppointmentTime (

						[BoardId],
						[WeekDay],
						[StartTime],
						[EndTime])
			values(		@dbId,
						5,
						9.00,
						17.00)
			Insert into AppointmentTime (

						[BoardId],
						[WeekDay],
						[StartTime],
						[EndTime])
			values(		@dbId,
						6,
						9.00,
						17.00)
			Insert into AppointmentTime (

						[BoardId],
						[WeekDay],
						[StartTime],
						[EndTime])
			values(		@dbId,
						7,
						null,
						null)*/
	select	Id,
			[LocationId],
			[SiteId],
			[TappId],
			[Room],
			[Comment],
			[AllowPhone],
			[AllowChat],
			[AllowVideo],
			[TimeSlotInterval]
			CreationTime 
	from Board 
	where @dbId = Id
	select	Id,
			[BoardId],
			[WeekDay],
			[StartTime],
			[EndTime],
			[CreationTime]
	from AppointmentTime 
	where @dbId = [BoardId]
end
go

